
# Сайт «Ситий Боб» — GitHub Pages

Статичный сайт с меню, корзиной и оформлением заказа в WhatsApp.

## Как развернуть на GitHub Pages
1. Создайте репозиторий на GitHub (например, `sitiy-bob-site`).
2. Загрузите файлы из этого архива в корень репозитория.
3. Включите Pages: Settings → Pages → Source: main / (root).
